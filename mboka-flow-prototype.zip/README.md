# Mboka Flow — prototype initial

## Ce que contient cette version
- Carte centrée sur Kinshasa (OpenStreetMap).
- Recherche de lieux via Nominatim.
- Géolocalisation du navigateur (autorisation requise).
- Calcul d'itinéraire routier via un service de démonstration OSRM.
- Signalements visuels locaux (ils ne sont ni sauvegardés durablement ni partagés).
- Structure PWA de base pour ajout à l'écran d'accueil.

## Limites importantes
Cette version est un prototype, pas une application de navigation certifiée :
- Les routes ne sont pas réellement vérifiées sur le terrain.
- Les durées n'intègrent pas nécessairement le trafic actuel.
- Les signalements restent dans la session du navigateur et ne sont pas envoyés à un serveur.
- Les services publics peuvent limiter ou interrompre les requêtes. Respectez les politiques d'utilisation d'OpenStreetMap, Nominatim et OSRM.
- La navigation vocale continue, le suivi GPS pendant le trajet, le mode hors ligne, les comptes et la synchronisation multi-utilisateurs ne sont pas implémentés.

## Lancer localement
Le plus simple est de publier le contenu du dossier `www` sur un hébergement HTTPS statique. Pour tester localement avec Python installé :
```bash
cd www
python -m http.server 8000
```
Puis ouvrez `http://localhost:8000`. La géolocalisation fonctionne généralement sur localhost ou HTTPS.

## Publier gratuitement avec GitHub Pages
1. Créez un dépôt public nommé `mboka-flow`.
2. Téléversez tous les fichiers du dossier `www` à la racine du dépôt (ou configurez Pages pour le dossier approprié).
3. Dans Settings → Pages, activez le déploiement depuis la branche principale et le dossier racine.
4. Attendez que GitHub fournisse l'adresse publiée.
5. Ouvrez l'adresse sur Android et autorisez la localisation.

## Étape suivante pour une vraie app Android
Sur Windows, installez Node.js et Android Studio, puis créez un projet Capacitor. La création d'une application Android native nécessite des outils de développement et des tests sur appareil. Pour une version commerciale, il faudra un backend pour enregistrer et modérer les signalements, surveiller les abus, et respecter les exigences de confidentialité.
